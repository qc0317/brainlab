# 核心研究对照表

由结构化提取数据自动生成；当前 14 条记录，均为部分提取，完整方法审核仍在进行。

同队列的不同随访不是独立重复验证；综述与原试验可能重叠。直接训练、综合方案与背景干预分别阅读。

## 直接认知训练

|研究|人群与对照|实际终点|效应|限制与待核|
|---|---|---|---|---|
|[active10](https://pubmed.ncbi.nlm.nih.gov/29201994/)|认知正常社区老年人；无训练|十年研究定义痴呆|速度HR0.71；95%CI0.50至0.998；P0.049|AD特异性发病未统一病理确认；完整终点与失访审核|
|[active20](https://pmc.ncbi.nlm.nih.gov/articles/PMC12884427/)|原ACTIVE中进入传统Medicare分析者；初始无训练及合资格组内未加强|二十年理赔ADRD|总体速度调整HR0.87；0.72至1.05。速度加加强0.75；0.59至0.95|整体速度组区间含1；加强路径不能替代总体随机比较。文字表格差异、资格流程、亚组与多重比较仍待审。|
|[lampit](https://pubmed.ncbi.nlm.nih.gov/25405755/)|认知正常老年人；各原试验对照|即刻未训练认知测试|综合g0.22；95%CI0.15至0.29|长期发病不是该综合终点；各领域与偏倚不同|
|[neuroracer](https://pubmed.ncbi.nlm.nih.gov/24005416/)|60至85岁老年人；单任务及无接触|任务成本及部分独立认知测试|摘要报告多任务成本及部分独立认知收益；逐项区间待提取|46人随机；长期临床发生未测；补充表待审|
|[neuroracer6](https://pubmed.ncbi.nlm.nih.gov/33789209/)|同一原试验回访者；原对照回访者|六年诊断版本任务与脑电|报告保持线索；完整组间估计待提取|不是独立重复试验；回访选择与缺失处理待审|
|[owen](https://pubmed.ncbi.nlm.nih.gov/20407435/)|在线研究参加者，完整年龄分布待核；原试验比较条件待完整提取|训练任务与未训练测试|受练任务改善，摘要未发现未训练任务迁移|11430是摘要样本描述；不能直接当作全部随机入组人数|
|[cochraneD](https://pubmed.ncbi.nlm.nih.gov/30909318/)|已有轻至中度痴呆者；对照或其他治疗分别比较|训练结束总体认知|对照SMD0.42；0.23至0.61；其他治疗0.21；−0.23至0.64|治疗阶段不是健康人发病预防；原试验重叠与偏倚待逐项审|

## 综合生活方式方案

|研究|人群与对照|实际终点|效应|限制与待核|
|---|---|---|---|---|
|[pointer](https://pmc.ncbi.nlm.nih.gov/articles/PMC12305445/)|有认知下降风险的60至79岁者；自主综合生活方式|两年认知复合分数年变化|年差0.029SD；95%CI0.008至0.050；P0.008|主动比较；游戏成分独立效果与临床发病未证明|
|[finger](https://pubmed.ncbi.nlm.nih.gov/25771249/)|60至77岁，CAIDE风险分数至少6、认知为年龄平均或略低者；完整排除标准待核；一般健康建议|两年NTB认知复合分数|年组间差0.022；95%CI0.002至0.042；P0.030|综合方案，不能隔离游戏；退出153人，逐组缺失待核|
|[mapt](https://pubmed.ncbi.nlm.nih.gov/28359749/)|原试验老年入组者，逐项标准待核；安慰剂|36个月认知复合分数|组合差0.093；CI0.001至0.184；调整P0.142。多领域0.079；−0.012至0.170；P0.179|原始CI与调整P不可替换；多重比较方法待核，总体未达到主要显著标准|

## 背景干预与新技能学习

|研究|人群与对照|实际终点|效应|限制与待核|
|---|---|---|---|---|
|[prediva](https://pubmed.ncbi.nlm.nih.gov/27474376/)|基层医疗诊所招募老年人；常规照护|全因痴呆发生|HR0.92；95%CI0.71至1.19；P0.54。事件121/1853与112/1601|诊所随机116家；不是认知游戏试验；随机人数不同于事件分析分母|
|[sprint](https://pubmed.ncbi.nlm.nih.gov/30688979/)|原降压试验入组者，完整标准待核；标准血压控制|可能痴呆与MCI分别判定|可能痴呆HR0.83；0.67至1.04；P0.10。MCI0.81；0.69至0.95；P0.007|MCI积极不能替代痴呆主要结果；血压不是游戏；后续随访待审|
|[achieve](https://pmc.ncbi.nlm.nih.gov/articles/PMC10529382/)|977名参加者，ARIC238与新招募739；健康教育对照|三年总体认知变化|总体差0.002SD；95%CI−0.077至0.081；P0.96|总体未显著；预设招募来源交互P0.010。精确亚组估计、多重比较及完整方法待核；不是游戏疗效。|
|[synapse](https://pubmed.ncbi.nlm.nih.gov/24214244/)|259入组、221完成14周的老年人；社交、居家安慰活动及无干预分别比较|情景记忆等独立测试|整体情景记忆交互F(1,179)=9.63，P0.002；逐条件Bonferroni-Holm校正后摄影vs安慰的情景记忆保留显著。原文净效应量摄影0.54、双项目0.22，脚注定义已核；CI与原始分数复算待核。|完成者分析、偏好排除与对照差异待核；项目名称不等于生物突触测量|

## 逐项效应

|研究与比较|终点|效应|95%区间|单位|P值|原文位置与说明|
|---|---|---|---|---|---|---|
|active10：初始速度训练 vs 对照|研究定义痴呆|HR 0.71|0.5 至 0.998|相对发生速率|0.049|原始摘要；不能换算为AD特异性绝对风险|
|active20：初始速度组总体 vs 对照|理赔ADRD|HR 0.87|0.72 至 1.05|相对发生速率|未录入|原文Table 2调整列；|
|active20：速度＋加强路径 vs 对照|理赔ADRD|HR 0.75|0.59 至 0.95|相对发生速率|未录入|原文Table 2调整列；路径比较不同于原速度组总体；资格与再次随机分配需要核对|
|active20：合资格速度组内：加强 vs 未加强|理赔ADRD|HR 0.81|0.66 至 1.0|相对发生速率|未录入|原文加强比较；区间上界1.00是原报告舍入值，不能自行解释边界显著性|
|active20：初始速度组总体 vs 对照|死亡竞争下的理赔ADRD|subdistribution HR 0.91|0.75 至 1.11|亚分布风险比|未录入|补充s003 Table S4 Model 2；Fine–Gray估计；不能与原因别HR或绝对风险降低混称。资格、分组及完整模型审核尚未完成。|
|active20：速度＋加强路径 vs 对照|死亡竞争下的理赔ADRD|subdistribution HR 0.77|0.61 至 0.98|亚分布风险比|未录入|补充s003 Table S4 Model 4；Fine–Gray估计；不能与原因别HR或绝对风险降低混称。资格、分组及完整模型审核尚未完成。|
|active20：合资格速度组内：加强 vs 未加强|死亡竞争下的理赔ADRD|subdistribution HR 0.78|0.63 至 0.96|亚分布风险比|未录入|补充s003 Table S4 Model 6；Fine–Gray估计；不能与原因别HR或绝对风险降低混称。资格、分组及完整模型审核尚未完成。|
|lampit：计算机认知训练 vs 原试验对照|即刻独立认知测试|Hedges g 0.22|0.15 至 0.29|标准差|未录入|原文总体元分析；|
|pointer：结构化 vs 自主综合方案|认知复合分数年变化|mean_difference 0.029|0.008 至 0.05|标准差/年|0.008|原始摘要；|
|cochraneD：训练 vs 对照条件|结束时总体认知|SMD 0.42|0.23 至 0.61|标准差|未录入|原综述Analysis 1.1；|
|cochraneD：训练 vs 其他治疗|结束时总体认知|SMD 0.21|-0.23 至 0.64|标准差|未录入|原始摘要；对照比较不可互换|
|finger：综合方案 vs 一般健康建议|认知年变化|mean_difference 0.022|0.002 至 0.042|NTB复合分数/年|0.03|原始摘要；|
|prediva：血管照护 vs 常规照护|全因痴呆|HR 0.92|0.71 至 1.19|相对发生速率|0.54|原始摘要；|
|sprint：强化 vs 标准降压|可能痴呆|HR 0.83|0.67 至 1.04|相对发生速率|0.1|原始摘要；|
|sprint：强化 vs 标准降压|MCI|HR 0.81|0.69 至 0.95|相对发生速率|0.007|原始摘要；|
|achieve：听力干预 vs 健康教育|三年总体认知变化|mean_difference 0.002|-0.077 至 0.081|标准差|0.96|原始摘要；|

## 其他原文统计

没有完整效应量与区间的比较不以零值补齐。
- achieve：ARIC vs de novo：干预效应差异；三年认知变化；interaction=未报告统计量；自由度[]；P=0.01；预设敏感性分析，原始摘要
- synapse：生产性vs接受性活动；情景记忆；condition_by_time_F=9.63；自由度[1, 179]；P=0.002；Cognitive-intervention analyses
- synapse：逐条件校正后保留摄影vs安慰情景记忆，不将未校正多项结果作为同等确定证据。

## 原文分母、模型与差异

### active20｜事件记录

Table 2：Ever diagnosed dementia

|群体|事件数|人数|
|---|---|---|
|control|239|491|
|memory|231|516|
|speed|223|512|
|reasoning|223|502|
|eligible_speed_booster|105|264|
|eligible_speed_no_booster|92|201|

描述事件比例不是固定二十年累计发病概率；群体范围与资格不同，不能把子组分母与总体混用。

模型：cause-specific hazard model

调整变量：baseline memory factor, baseline reasoning factor, baseline speed factor, age, race, sex, self-reported health, years of education, ischemia, heart attack, atrial fibrillation, congestive heart failure, diabetes, hypertension, marital status, smoking status, site, replicate code

three separate regressions comparing randomized booster vs randomized no-booster within intervention arms, adjusted for covariates

脚注样本措辞、完整模型实现及补充表星号定义仍待核；已提取S4三个指定比较。

原文差异：Results text vs Table 2 speed+booster columns

文字：adjusted HR 0.74 (0.59–0.93)；表未调整：0.74 (0.59–0.93)；表调整：0.75 (0.59–0.95)

未裁决，规范记录按表列，保留文字差异

### synapse｜效应定义

干预组Blom分数前后变化－安慰组Blom分数前后变化

原文测验前标准差，具体范围及数值仍待核

Footnote 2；未录入，不表示零区间


[下载结构化JSON](../../data/alzheimer/trial-extractions.json)
