BrainLab个人研究包
打开 research-programs/alzheimer/DRAFT.md 阅读正文；图片使用相对路径，解压时请保留目录。
结构化对照记录位于 data/alzheimer/trial-extractions.json。
指定领域复算：data/alzheimer/lampit-reanalysis.json 保存输入/方法/结果；可运行 python3 scripts/reproduce_lampit.py 核算。仅用标准库，不改变输入。
此包为审核中的研究草稿，数量达标不表示科学审核完成。
原论文入口保留在正文中；图注记录来源、许可及裁剪。
